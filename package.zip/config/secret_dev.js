module.exports = {
  database: "mongodb://localhost:27017/brav",
  port: 3000,
  secretKey: "Sayatkey"
};
